<?php

return [
    'failed'   => 'As credenciais informadas não correspondem com nossos registros.',
    'password' => 'A senha fornecida está incorreta.',
    'throttle' => 'Muitas tentativas de login. Por favor, tente novamente em :seconds segundos.',
    'unauthenticated' => 'Não autenticado.', 
];