<footer class="app-footer"> <!--begin::To the end-->
            <div class="float-end d-none d-sm-inline">Desenvolvido pela Academia Dev Fitness</div> <!--end::To the end--> <!--begin::Copyright--> <strong>
                Copyright &copy; 2014-2024&nbsp;
                <a href="https://www.rodrigozambon.com.br/devfront/" class="text-decoration-none">Dev Fitness</a>.
            </strong>
            Todos os Direitos Reservados.
            <!--end::Copyright-->
        </footer>